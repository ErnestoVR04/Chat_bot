from GuiApp import ChatApplication

if __name__ == '__main__':
    ChatApplication().run()