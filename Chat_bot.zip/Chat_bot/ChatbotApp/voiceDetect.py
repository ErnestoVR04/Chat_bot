import speech_recognition as sr

def recognize_voice():
    # Inicializa el reconocedor
    recognizer = sr.Recognizer()

    try:
        with sr.Microphone() as source:
            print("Escuchando...")
            recognizer.adjust_for_ambient_noise(source, duration=0.2)
            audio = recognizer.listen(source)
            text = recognizer.recognize_google(audio, language="es-ES")  # Cambia a tu idioma si es necesario
            text = text.lower()
            return text  # Retorna el mensaje detectado
    except sr.RequestError as e:
        print("No se pudieron solicitar resultados; {0}".format(e))
        return None
    except sr.UnknownValueError:
        print("No se pudo entender lo que dijiste")
        return None