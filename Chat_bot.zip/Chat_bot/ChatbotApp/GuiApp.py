from tkinter import *
from chat import get_response, bot_name
from voiceDetect import recognize_voice
import pyttsx3 


BG_GRAY = "#FFE9B5"
BG_COLOR = "#0087FF"
TEXT_COLOR = "#FFFFFF"

FONT = "Helvetica 14"
FONT_BOLD = "Helvetica 13 bold"

class ChatApplication:
    
    def __init__(self):
        self.window = Tk()
        self._setup_main_window()
        
    def run(self):
        self.window.mainloop()
        
    def _setup_main_window(self):
        self.window.title("Cafe Shrule")
        self.window.resizable(width=False, height=False)
        self.window.configure(width=470, height=550, bg=BG_COLOR)
        icon = PhotoImage(file=r"ChatbotApp\src\coffee-cup.png")
        self.window.wm_iconphoto(False, icon)

        # head label
        head_label = Label(self.window, bg=BG_COLOR, fg=TEXT_COLOR, text="Bienvenido", font=FONT_BOLD, pady=10)
        head_label.place(relwidth=1)
        
        # tiny divider
        line = Label(self.window, width=450, bg=BG_GRAY)
        line.place(relwidth=1, rely=0.09, relheight=0.012)
        
        # text widget
        self.text_widget = Text(self.window, width=20, height=2, bg="#FFF8E7", fg="#000000",
                                font=FONT, padx=5, pady=5)
        self.text_widget.place(relheight=0.745, relwidth=1, rely=0.08)
        self.text_widget.configure(cursor="arrow", state=DISABLED)
        
        # scroll bar
        scrollbar = Scrollbar(self.text_widget)
        scrollbar.place(relheight=1, relx=0.974)
        scrollbar.configure(command=self.text_widget.yview)
        
        # bottom label
        bottom_label = Label(self.window, bg=BG_GRAY, height=80)
        bottom_label.place(relwidth=1, rely=0.825)
        
        # message entry box
        self.msg_entry = Entry(bottom_label, bg="#FFF7E4", fg="#000000", font=FONT)
        self.msg_entry.place(relwidth=0.50, relheight=0.06, rely=0.008, relx=0.011)
        self.msg_entry.focus()
        self.msg_entry.bind("<Return>", self._on_enter_pressed)
        
        #Send button
        send_button = Button(bottom_label, text="Enviar", font=FONT_BOLD, width=20, bg=TEXT_COLOR,command=lambda: self._on_enter_pressed(None))
        send_button.place(relx=0.54, rely=0.008, relheight=0.06, relwidth=0.22)

        #voice button
        voice_button = Button(bottom_label, text="Voz", font=FONT_BOLD, width=20, bg=TEXT_COLOR,command= lambda: self._on_audio_pressed(None))
        voice_button.place(relx=0.77, rely=0.008, relheight=0.035, relwidth=0.22)

        #ChatBotAudio checkbutton
        self.ChatbotAudioSlection = BooleanVar()
        prueba_check = Checkbutton(bottom_label, text="Chatbot Audio", variable=self.ChatbotAudioSlection, command=self._selectChatBotAdudio)
        prueba_check.place(relx=0.77, rely=0.049, relheight=0.019, relwidth=0.22)

    #ChatBotAudio select
    def _selectChatBotAdudio(self):
        if self.ChatbotAudioSlection.get():
            return True
        else:
            return False

    #Audio user buttton
    def _on_audio_pressed(self, event):
        msg = recognize_voice()
        self._insert_message(msg, "Ernesto")

    #Chatbot audio
    def _on_Chatbot_audio(self, msg):
        engine = pyttsx3.init()
        engine.setProperty("rate", 120)
        engine.say(msg)
        return engine

    #Enter and submit button
    def _on_enter_pressed(self, event):
        msg = self.msg_entry.get()
        self._insert_message(msg, "Tu")
    
    #Mss1 and Mss2
    def _insert_message(self, msg, sender):
        if not msg:
            return
        
        self.msg_entry.delete(0, END)
        msg1 = f"{sender}: {msg}\n"
        self.text_widget.configure(state=NORMAL)
        self.text_widget.insert(END, msg1)
        self.text_widget.configure(state=DISABLED)
        msg2 = f"{get_response(msg)}"
        if self._selectChatBotAdudio():
            self._on_Chatbot_audio(msg2).runAndWait()
        self.text_widget.configure(state=NORMAL)
        self.text_widget.insert(END, f"{bot_name}: {msg2}\n\n" )
        self.text_widget.configure(state=DISABLED)
        self.text_widget.see(END)